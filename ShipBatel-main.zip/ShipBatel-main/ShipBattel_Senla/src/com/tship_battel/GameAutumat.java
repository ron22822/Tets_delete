package com.tship_battel;

public enum GameAutumat {
    GAME_START,
    GAME_CHOOSE,
    GAME_ARRANGE,
    GAME_SHOOT,
    GAME_END;
}
